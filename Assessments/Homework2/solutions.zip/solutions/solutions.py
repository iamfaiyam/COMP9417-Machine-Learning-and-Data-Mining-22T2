#!/usr/bin/env python
# coding: utf-8

# # 💻COMP9417 - Homework 1

# ### by Faiyam Islam (z5258151)

# In[1]:


# Packages for all questions 
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from scipy.optimize import minimize 
from sklearn.linear_model import LogisticRegression 
from sklearn.metrics import log_loss
import matplotlib.pyplot as plt 


# In[2]:


# Question 1b
from mpl_toolkits import mplot3d

def func(x, y):
    return 100 * (y - x**2)**2 + (1 - x)**2

# create two one-dimensional grids using linspace
x = np.linspace(-5, 5, 50) 
y = np.linspace(-5, 5, 50) 

# combine the two one-dimensional grids into one two-dimensional grid
X, Y = np.meshgrid(x, y) 

# evaluate the function at each element of the two dimensional grid
Z = func(X, Y) 

# create plot 
fig = plt.figure(figsize = (7, 7))
ax = plt.axes(projection = '3d')
ax.plot_surface(X, Y, Z, cmap = 'plasma')
plt.show()


# In[3]:


# Question 1c

import numpy as np 
def gradient(x, y):
    derivative = np.array([[-400*x*(y-x**2)-2+2*x], [200*(y-x**2)]])
    return derivative

def hessian(x, y):
    Hessian = np.array([[-400*(y-3*x**2)+2, -400*x], [-400*x, 200]])
    return Hessian

x = np.array([[-1.2, 1]])
x = x.T
i = 1
while np.linalg.norm(gradient(x[0][0], x[1][0]), ord = 2) >= 0.000001:
    x = x - np.matmul(np.linalg.inv(hessian(x[0][0], x[1][0])), 
                     gradient(x[0][0], x[1][0]))
    print(x)
    i


# In[4]:


# Question 2d
songs_data = pd.read_csv('songs.csv')

# Part (I): Removing the features
remove_features = ['Artist Name', 'Track Name', 'key', 'mode', 'time_signature', 'instrumentalness']
songs_data = songs_data.drop(remove_features, axis = 1) 

# Part (II): Recoding target variable as y = 1 (hiphop) and y = 0 (pop) 
songs_data = songs_data[(songs_data['Class'] == 5) | (songs_data['Class'] == 9)]
songs_data['Class'].replace([5, 9], [1, 0], inplace = True) 
songs_data = songs_data.reset_index(drop = True) 

# Part (III): Removing rows that have missing values 
songs_data = songs_data.dropna()
songs_data.isnull().sum()

# Part (IV): Splitting data to X_train, X_test, Y_train and Y_test
X_train, X_test, Y_train, Y_test = train_test_split(songs_data.iloc[:,0:-1], songs_data.iloc[:,-1], test_size=0.3, random_state=23)

# Part (V): Scaling the data 
scaler = StandardScaler().fit(X_train) 
X_train = scaler.transform(X_train) 
X_test = scaler.transform(X_test) 

# Part (VI): Printing out first and last rows of X_train, X_test, Y_train, Y_test
X_train = pd.DataFrame(X_train, columns = ['Popularity', 'danceability', 'energy', 'loudness', 'speechiness', 'acousticness', 
'liveness', 'valence', 'tempo', 'duration_in min/ms'])

X_test = pd.DataFrame(X_test, columns = ['Popularity', 'danceability', 'energy', 'loudness', 'speechiness', 'acousticness', 
'liveness', 'valence', 'tempo', 'duration_in min/ms'])

Y_train = pd.DataFrame(Y_train, columns = ['Class'])

Y_test = pd.DataFrame(Y_test, columns = ['Class'])


# In[5]:


X_train_first_row = X_train.iloc[0, 0:3]
print(X_train_first_row) 


# In[6]:


X_train_last_row = X_train.iloc[-1, 0:3]
print(X_train_last_row) 


# In[7]:


X_test_first_row = X_test.iloc[0, 0:3]
print(X_test_first_row) 


# In[8]:


X_test_last_row = X_test.iloc[-1, 0:3]
print(X_test_last_row) 


# In[9]:


Y_train_first_row = Y_train.iloc[0]
print(Y_train_first_row) 


# In[10]:


Y_train_last_row = Y_train.iloc[-1]
print(Y_train_last_row) 


# In[11]:


Y_test_first_row = Y_test.iloc[0]
print(Y_test_first_row) 


# In[12]:


Y_test_last_row = Y_test.iloc[-1]
print(Y_test_last_row) 


# In[13]:


# Question 2e

n, m = X_train.shape 
fig, ax = plt.subplots(3, 3, figsize = (10, 10))
steps = 1 

x = X_train
y = np.array(Y_train) 

# Logistic sigmoid function
def logistic_function(b_0, b_k, x, y, n):
    num = 0 
    for i in range(1, n): 
        value = num 
        # logistic regression 
        num = y[i] * np.log(1 + np.exp(-b_0 - b_k.T @ x[i])) + (1 - y[i]) * (np.log(1/(1 - (1 + np.exp(-b_0 - b_k.T @ x[i])) ** -1)))
        num = value + num 
    return num 

lambda_ = 0.5

# Defined loss function 
def loss_function(b_0, b_k, lambda_, x, y, n): 
    return (1/2) * (np.linalg.norm(b_k, 2)) ** 2 + (lambda_ / n) * (logistic_function(b_0, b_k, x, y, n))

epoch_value = 60 
a = 0.5 
b = 0.8

b_0 = [[0.]]
b_k = [[0.]]
print(loss_function(b_0, b_k, lambda_, x, y, n))

while loss_function(b_0, b_k, lambda_, x, y, n) > (loss_function(b_0, b_k, lambda_, x, y, n) - (a * steps)) * (np.linalg.norm(loss_function(b_0, b_k, lambda_, x, y, n), 2) ** 2):
    b_0 = np.zeros(5) 
    b_k = np.zeros(5)
    
    j = 0 
    while epoch > j:
        # not sure what to do from here
        
# Intuition: Produce 2 plots which indicate the step sizes and the train losses of each implemention including BLS, for a = 0.5, 
# and b = 0.8. In the while epoch > j loop, calculate the sum of the k values that are lower than epoch and then compute
# the difference between the algorithms, BLS and gradient descent (which is also calculated after the while loop). 


# In[14]:


# Question 3b

import matplotlib.pyplot as plt

xrange = np.linspace(1, 100, 1000)
sigma = 1 

bias_tilda = lambda n: n * 0
bias_mle = lambda n: -sigma **2 / n

bias_tilda_value = bias_tilda(xrange)
bias_mle_value = bias_mle(xrange)

plt.figure(figsize = (10, 10))
plt.plot(xrange, bias_mle_value, label = 'Old variance estimator', color = 'purple')
plt.plot(xrange, bias_tilda_value, label = 'New variance estimator', color = 'green')

plt.legend()
plt.xlabel('Sample size')
plt.ylabel('Bias')
plt.title('Bias of estimator')
plt.show()


# In[15]:


xrange = np.linspace(2, 200, 2000)

var_tilda = lambda n: 2 * sigma**4 * (n - 1) / n**2 
var_mle = lambda n: 2 * sigma**4 / (n - 1) 

var_tilda_values = var_tilda(xrange) 
var_mle_values = var_mle(xrange) 

plt.figure(figsize = (10, 10)) 
plt.plot(xrange, var_tilda_values, label = 'Old variance estimator', color = 'purple')
plt.plot(xrange, var_mle_values, label = 'New variance estimator', color = 'green') 

plt.legend()
plt.xlabel('Sample size')
plt.ylabel('Variance') 
plt.title('Variance of estimator')
plt.show()


# In[16]:


# Question 3c

sigma = 1 
mse_old_estimator = lambda n: (sigma**4*(2*n - 1)) / n**2 
mse_new_estimator = lambda n: 2*sigma**4 / (n - 1) 

xrange = np.linspace(1, 200, 100) 

plt.plot(xrange, mse_old_estimator(xrange), color = "purple", label = "old estimator")
plt.plot(xrange, mse_new_estimator(xrange), color = "green", label = "new estimator")
plt.legend(loc = 'upper right')
plt.xlabel("Sample size")
plt.ylabel("MSE")
plt.show()

