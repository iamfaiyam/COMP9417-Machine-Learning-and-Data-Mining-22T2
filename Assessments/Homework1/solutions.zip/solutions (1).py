#!/usr/bin/env python
# coding: utf-8

# # 💻COMP9417 - Homework 1
# ### by Faiyam Islam (z5258151)

# In[1]:


# Packages for all questions
import matplotlib.pyplot as plt
import numpy as np
from sklearn.linear_model import LinearRegression
import math
import torch 
import torch.nn as nn
from torch import optim
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split


# ### Question 1a

# In[2]:


A = np.array([[1, 2, 1, -1], [-1, 1, 0, 2], [0, -1, -2, 1]])
b = np.array([3, 2, -2])

alpha = 0.1
gamma = 0.2

def gradient_function(x, A, b):
    return -1 * A.T @ b + A.T @ A @ x + gamma * np.eye(4) @ x

x0 = [0, 0, 0, 0]
x1 = [1, 1, 1, 1]

norm2 = 1
k = 0
while norm2 >= 0.001:
    delta = gradient_function(x1, A, b)
    norm2 = np.linalg.norm(delta, ord = 2)
    x0 = x1 - alpha * delta
    print(k, np.round(x1, 4))
    x1 = x0
    k = k + 1


# ### Question 1c

# In[3]:


A = torch.tensor(A).float()
b = torch.tensor(b).float()

gamma = 0.2
alpha = 0.1

class MyModel(nn.Module):
    def __init__(self):
        super().__init__()        
        self.X = nn.Parameter(torch.ones(4, requires_grad = True))
    def forward(self):
        return self.X

model = MyModel()
optimizer = optim.SGD(model.parameters(), lr = alpha) 
k = 1 
while k >= 0.001:
    x = model.forward()
    x_hat = A @ x
    res = x_hat - b
    loss_f = ((res**2).sum())/2 + ((x**2).sum()) * (gamma / 2)
    
    # similar to part a except we use tensor
    loss = -1 * A.T @ b + A.T @ A @ x + gamma * torch.eye(4) @ x
    k = math.sqrt(torch.sum(loss**2))
    print(model.X.data)    
    loss_f.backward()
    optimizer.step()
    optimizer.zero_grad()
    
print("x hat using PyTorch w model: ", model.X.data)


# ### Question 1d

# In[4]:


car_data = pd.read_csv('CarSeats.csv')
categorical_variables = ['ShelveLoc', 'Urban', 'US']
numerical_data = car_data.drop(categorical_variables, axis = 1)
response = ['Sales']
predictors = [x for x in list(numerical_data.columns) if x not in response]
scaled_data = StandardScaler()
numerical_data[predictors] = scaled_data.fit_transform(numerical_data[predictors])


# In[5]:


numerical_data[predictors].mean()


# In[6]:


numerical_data[predictors].var()


# In[7]:


response_mean = numerical_data[response].mean()
numerical_data[response] = numerical_data[response] - response_mean


# In[8]:


X_train, X_test, Y_train, Y_test = train_test_split(numerical_data.iloc[:,1:], numerical_data.iloc[:,0], 
                                                    test_size = 0.5, shuffle=False)


# In[9]:


X_train.head(1)


# In[10]:


X_train.tail(1)


# In[11]:


X_test.head(1)


# In[12]:


X_test.tail(1)


# In[13]:


Y_train.head(1)


# In[14]:


Y_train.tail(1)


# In[15]:


Y_test.head(1)


# In[16]:


Y_test.tail(1)


# ### Question 1e

# In[17]:


X_T = X_train.T
Ridge_parameter = np.linalg.inv(X_T @ X_train + 0.5 * 200 * np.identity(7)) @ X_T @ Y_train
print(Ridge_parameter)


# ### Question 1g

# In[18]:


# Dataframe with all features
B0 = pd.DataFrame({'CompPrice': [1], 'Income': [1], 'Advertising':[1], 'Population':[1], 
                  'Price':[1], 'Age':[1], 'Education':[1]})

# betas containing 7 variables and 1 array
b0 = B0.values.reshape(7, 1)
x = X_train.values.reshape(200, 7)
# print(x)

# X transppose with 7 variables and sample = 200
xt = x.T.reshape(7, 200)
y = Y_train.values.reshape(200, 1)
# print(y)

# Step sizes for alpha
alpha_values = [0.000001, 0.000005, 0.00001, 0.00005, 0.0001, 0.0005, 0.001, 0.005, 0.01]

# phi = 0.5
loss_hat = np.linalg.norm(y - x @ Ridge_parameter, ord = 2)**2 / 200 + 0.5 * np.linalg.norm(Ridge_parameter, ord = 2)**2

# Loss function for Ridge Regression
def ridge_loss(y, x, B):
    return np.linalg.norm(y - x @ B, ord = 2)**2/200 + 0.5 * np.linalg.norm(B, ord = 2)**2


# In[19]:


# beta values for GD steps
def betas(b0, x, y, xt, alpha):
    b = b0
    Betas = []
    Betas.append(b)
    # we run the algorithm for 1000 epochs
    for i in range(1, 1001):
        B = b - alpha * (-2 * xt @ (y - x @ b) + 200 * b) / 200
        b = B
        Betas.append(B)
    return Betas

# delta values for GD steps
def deltas(b0, x, y, xt, loss_value, alpha):
    Deltas = []
    Betas = betas(b0, x, y, xt, alpha)
    
    for B in Betas:
        loss = np.linalg.norm(y - x @ B, ord = 2)**2/200 + 0.5 * np.linalg.norm(B, ord = 2)**2
        d = loss - loss_value
        Deltas.append(d)
    return Deltas

# function to generate 3 x 3 grid plot
def grid_plot(b0, x, y, xt, loss_value, alpha):
    D = deltas(b0, x, y, xt, loss_value, alpha)
    plt.plot(np.arange(0, len(D)), D, color = 'green')
    plt.xlabel("k")
    plt.ylabel("delta^(k)")
    plt.title("alpha:" + str(alpha), pad = 15)
    
i = 1
for alpha in alpha_values: 
    plt.subplot(3, 3, i)
    grid_plot(b0, x, y, xt, loss_hat, alpha)
    i += 1

plt.tight_layout()
plt.show()


# In[20]:


# Since alpha = 0.01 is the best step-size we use that
alpha = 0.01
b = betas(b0, x, y, xt, alpha)
beta = b[1000] # epochs = 1000

MSE_train = (np.linalg.norm(y - x @ beta, ord = 2)**2) / 200
Y_test_values = Y_test.values.reshape(200, 1)
X_test_values = X_test.values.reshape(200, 7)
MSE_test = (np.linalg.norm(Y_test_values - X_test_values @ beta, ord = 2)**2) / 200

# Train MSE
print(MSE_train)

# Test MSE
print(MSE_test)


# ### Question 1h

# In[21]:


alpha_values = [0.000001, 0.000005, 0.00001, 0.00005, 0.0001, 0.0005, 0.001, 0.006, 0.02]

def betas(b0, X_train, Y_train, alpha):
    b = b0
    SGD_beta = []
    SGD_beta.append(b)
    for j in range(1, 1001):
        j = j % 200
        if j == 0:
            j = 200
        X = X_train.loc[j - 1]
        Y = Y_train.loc[j - 1]
        
        x = X.values.reshape(7, 1)
        x_t = x.T
        
        B = b - alpha * (-2 * x @ (Y - x_t @ b) + b)
        SGD_beta.append(B)
        b = B
    return SGD_beta

def deltas(b0, X_train, Y_train, loss_hat, alpha):
    y = Y_train.values.reshape(200, 1)
    x = X_train.values
    SGD_delta = []
    SGD_beta = betas(b0, X_train, Y_train, alpha)
    for B in SGD_beta:
        loss = np.linalg.norm(y - x @ B, ord = 2)**2 / 200 + 0.5 * np.linalg.norm(B, ord = 2)**2
        delta = loss - loss_hat
        SGD_delta.append(delta)
    return SGD_delta

def SGD_plot(b0, X_train, Y_train, loss_hat, alpha):
    SGD_delta = deltas(b0, X_train, Y_train, loss_hat, alpha)
    plt.plot(np.arange(0, len(SGD_delta)), SGD_delta, color = 'green')
    plt.xlabel("k")
    plt.ylabel("SGD_delta")
    plt.title("alpha = " + str(alpha), pad = 15)
    
j = 1 
for alpha in alpha_values:
    plt.subplot(3, 3, j)
    SGD_plot(b0, X_train, Y_train, loss_hat, alpha)
    j += 1

plt.tight_layout()
plt.show()


# In[22]:


# Since alpha = 0.006 is the best step-size we use that
SGD_Beta = betas(b0, X_train, Y_train, 0.006)
beta_values = SGD_Beta[1000]

MSE_train = (np.linalg.norm(y - x @ beta_values, ord = 2)**2) / 200
MSE_test = (np.linalg.norm(Y_test_values - X_test_values @ beta_values, ord = 2)**2) / 200

# Train MSE
print(MSE_train)

# Test MSE
print(MSE_test)


# ### Question 1k

# In[ ]:


def total_betas(X, y, i, c, size):
    sum = 0
    for i in range(size):
        sum = X[i][y] * # not sure what to do here 
        

def minimisation(X, y, size):
    betas = np.ones(7) 
    Betas = []
    Deltas = []
    # Terminate the algorithm after 10 cycles
    for i in range(10):
        for i in range(7):
            # Matrix multiplication, but delete the first row
            constant = np.matmul(np.delete(X, i, 1), np.delete(beta, i, 0))
            betas[i] = total_betas(X, y, i, c, size)
            Betas.append(betas)
            Deltas.append()
            # not sure what to do after this

# Intuition: Produce grid plots indicating the batch GD and SGD and their comparisons. Then using the implementation from 
# the previous question and generate MSE train and MSE test which will take in the total sum of the betas (updating).

